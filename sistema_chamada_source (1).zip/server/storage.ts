import { 
  students, classSchedules, attendanceRecords,
  type Student, type InsertStudent, 
  type ClassSchedule, type InsertClassSchedule,
  type AttendanceRecord, type InsertAttendanceRecord,
  type AttendanceStatus
} from "@shared/schema";

export interface IStorage {
  // Student operations
  getStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;
  
  // Attendance operations
  getAttendanceRecords(date?: Date): Promise<AttendanceRecord[]>;
  getStudentAttendance(studentId: number): Promise<AttendanceRecord[]>;
  recordAttendance(record: InsertAttendanceRecord): Promise<AttendanceRecord>;
  updateAttendanceRecord(id: number, status: AttendanceStatus): Promise<AttendanceRecord | undefined>;
  getAttendanceStats(): Promise<{ total: number, absent: number, justified: number }>;
  
  // Class schedule operations
  getClassSchedules(): Promise<ClassSchedule[]>;
  createClassSchedule(schedule: InsertClassSchedule): Promise<ClassSchedule>;
  updateClassSchedule(id: number, schedule: Partial<InsertClassSchedule>): Promise<ClassSchedule | undefined>;
  deleteClassSchedule(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private students: Map<number, Student>;
  private attendanceRecords: Map<number, AttendanceRecord>;
  private classSchedules: Map<number, ClassSchedule>;
  private currentStudentId: number;
  private currentAttendanceId: number;
  private currentScheduleId: number;

  constructor() {
    this.students = new Map();
    this.attendanceRecords = new Map();
    this.classSchedules = new Map();
    this.currentStudentId = 1;
    this.currentAttendanceId = 1;
    this.currentScheduleId = 1;
    
    // Initialize with some default class schedules
    this.initializeDefaultSchedules();
  }

  private initializeDefaultSchedules() {
    const defaultSchedules: InsertClassSchedule[] = [
      // Monday
      { dayOfWeek: "monday", subject: "Matemática", startTime: "07:00", endTime: "07:50" },
      { dayOfWeek: "monday", subject: "Português", startTime: "07:50", endTime: "08:40" },
      { dayOfWeek: "monday", subject: "História", startTime: "08:40", endTime: "09:30" },
      { dayOfWeek: "monday", subject: "Intervalo", startTime: "09:30", endTime: "09:50" },
      { dayOfWeek: "monday", subject: "Geografia", startTime: "09:50", endTime: "10:40" },
      { dayOfWeek: "monday", subject: "Ciências", startTime: "10:40", endTime: "11:30" },
      
      // Tuesday
      { dayOfWeek: "tuesday", subject: "Português", startTime: "07:00", endTime: "07:50" },
      { dayOfWeek: "tuesday", subject: "Matemática", startTime: "07:50", endTime: "08:40" },
      { dayOfWeek: "tuesday", subject: "Artes", startTime: "08:40", endTime: "09:30" },
      { dayOfWeek: "tuesday", subject: "Intervalo", startTime: "09:30", endTime: "09:50" },
      { dayOfWeek: "tuesday", subject: "Ed. Física", startTime: "09:50", endTime: "10:40" },
      { dayOfWeek: "tuesday", subject: "Inglês", startTime: "10:40", endTime: "11:30" },
      
      // Wednesday
      { dayOfWeek: "wednesday", subject: "Inglês", startTime: "07:00", endTime: "07:50" },
      { dayOfWeek: "wednesday", subject: "Ciências", startTime: "07:50", endTime: "08:40" },
      { dayOfWeek: "wednesday", subject: "Matemática", startTime: "08:40", endTime: "09:30" },
      { dayOfWeek: "wednesday", subject: "Intervalo", startTime: "09:30", endTime: "09:50" },
      { dayOfWeek: "wednesday", subject: "Português", startTime: "09:50", endTime: "10:40" },
      { dayOfWeek: "wednesday", subject: "Ed. Física", startTime: "10:40", endTime: "11:30" },
      
      // Thursday
      { dayOfWeek: "thursday", subject: "Geografia", startTime: "07:00", endTime: "07:50" },
      { dayOfWeek: "thursday", subject: "História", startTime: "07:50", endTime: "08:40" },
      { dayOfWeek: "thursday", subject: "Português", startTime: "08:40", endTime: "09:30" },
      { dayOfWeek: "thursday", subject: "Intervalo", startTime: "09:30", endTime: "09:50" },
      { dayOfWeek: "thursday", subject: "Matemática", startTime: "09:50", endTime: "10:40" },
      { dayOfWeek: "thursday", subject: "Artes", startTime: "10:40", endTime: "11:30" },
      
      // Friday
      { dayOfWeek: "friday", subject: "Ciências", startTime: "07:00", endTime: "07:50" },
      { dayOfWeek: "friday", subject: "Geografia", startTime: "07:50", endTime: "08:40" },
      { dayOfWeek: "friday", subject: "Inglês", startTime: "08:40", endTime: "09:30" },
      { dayOfWeek: "friday", subject: "Intervalo", startTime: "09:30", endTime: "09:50" },
      { dayOfWeek: "friday", subject: "História", startTime: "09:50", endTime: "10:40" },
      { dayOfWeek: "friday", subject: "Matemática", startTime: "10:40", endTime: "11:30" },
    ];
    
    defaultSchedules.forEach(schedule => {
      this.createClassSchedule(schedule);
    });
  }

  // Student operations
  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const id = this.currentStudentId++;
    const newStudent = { ...student, id };
    this.students.set(id, newStudent);
    return newStudent;
  }

  async updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined> {
    const existingStudent = this.students.get(id);
    if (!existingStudent) {
      return undefined;
    }
    
    const updatedStudent = { ...existingStudent, ...student };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    return this.students.delete(id);
  }

  // Attendance operations
  async getAttendanceRecords(date?: Date): Promise<AttendanceRecord[]> {
    const records = Array.from(this.attendanceRecords.values());
    
    if (date) {
      const dateString = date.toISOString().split('T')[0];
      return records.filter(record => {
        const recordDate = new Date(record.date).toISOString().split('T')[0];
        return recordDate === dateString;
      });
    }
    
    return records;
  }

  async getStudentAttendance(studentId: number): Promise<AttendanceRecord[]> {
    const records = Array.from(this.attendanceRecords.values());
    return records.filter(record => record.studentId === studentId);
  }

  async recordAttendance(record: InsertAttendanceRecord): Promise<AttendanceRecord> {
    // Check if record already exists for student, date and period
    const records = Array.from(this.attendanceRecords.values());
    const existingRecord = records.find(
      r => r.studentId === record.studentId && 
           new Date(r.date).toISOString().split('T')[0] === new Date(record.date).toISOString().split('T')[0] &&
           r.period === record.period
    );
    
    if (existingRecord) {
      // Update existing record
      existingRecord.status = record.status;
      if (record.period) {
        existingRecord.period = record.period;
      }
      this.attendanceRecords.set(existingRecord.id, existingRecord);
      return existingRecord;
    }
    
    // Create new record
    const id = this.currentAttendanceId++;
    const newRecord = { ...record, id };
    this.attendanceRecords.set(id, newRecord);
    return newRecord;
  }

  async updateAttendanceRecord(id: number, status: AttendanceStatus): Promise<AttendanceRecord | undefined> {
    const record = this.attendanceRecords.get(id);
    if (!record) {
      return undefined;
    }
    
    const updatedRecord = { ...record, status };
    this.attendanceRecords.set(id, updatedRecord);
    return updatedRecord;
  }

  async getAttendanceStats(): Promise<{ total: number, absent: number, justified: number }> {
    const records = Array.from(this.attendanceRecords.values());
    
    const absent = records.filter(r => r.status === "absent").length;
    const justified = records.filter(r => r.status === "justified").length;
    
    return {
      total: records.length,
      absent,
      justified
    };
  }

  // Class schedule operations
  async getClassSchedules(): Promise<ClassSchedule[]> {
    return Array.from(this.classSchedules.values());
  }

  async createClassSchedule(schedule: InsertClassSchedule): Promise<ClassSchedule> {
    const id = this.currentScheduleId++;
    const newSchedule = { ...schedule, id };
    this.classSchedules.set(id, newSchedule);
    return newSchedule;
  }

  async updateClassSchedule(id: number, schedule: Partial<InsertClassSchedule>): Promise<ClassSchedule | undefined> {
    const existingSchedule = this.classSchedules.get(id);
    if (!existingSchedule) {
      return undefined;
    }
    
    const updatedSchedule = { ...existingSchedule, ...schedule };
    this.classSchedules.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async deleteClassSchedule(id: number): Promise<boolean> {
    return this.classSchedules.delete(id);
  }
}

export const storage = new MemStorage();
