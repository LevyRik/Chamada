import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Clock, Settings, BookOpen } from "lucide-react";
import { ScheduleConfigDialog } from "@/components/ScheduleConfigDialog";
import { SubjectConfigDialog } from "@/components/SubjectConfigDialog";
import { ClassSchedule } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function Schedule() {
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [subjectDialogOpen, setSubjectDialogOpen] = useState(false);
  const [customSubjects, setCustomSubjects] = useState<any>(null);
  const [periods, setPeriods] = useState<Record<string, string>>({
    period1: "1ª Aula (07:00 - 08:00)",
    period2: "2ª Aula (08:00 - 09:00)",
    period3: "3ª Aula (09:15 - 10:15)",
    interval: "Intervalo (09:00 - 09:15)",
    period4: "4ª Aula (10:15 - 11:15)",
    period5: "5ª Aula (11:15 - 12:15)",
  });
  
  const { data: schedules, isLoading } = useQuery<ClassSchedule[]>({
    queryKey: ["/api/schedule"]
  });
  
  // Carrega as configurações de horário e disciplinas do localStorage
  useEffect(() => {
    const loadScheduleConfig = () => {
      const configStr = localStorage.getItem('scheduleConfig');
      if (configStr) {
        try {
          const config = JSON.parse(configStr);
          
          setPeriods({
            period1: `1ª Aula (${config.period1Start} - ${config.period1End})`,
            period2: `2ª Aula (${config.period2Start} - ${config.period2End})`,
            period3: `3ª Aula (${config.period3Start} - ${config.period3End})`,
            interval: `Intervalo (${config.intervalStart} - ${config.intervalEnd})`,
            period4: `4ª Aula (${config.period4Start} - ${config.period4End})`,
            period5: `5ª Aula (${config.period5Start} - ${config.period5End})`,
          });
        } catch (e) {
          console.error("Erro ao carregar configurações de horário", e);
        }
      }
    };
    
    const loadSubjectsConfig = () => {
      const configStr = localStorage.getItem('subjectsConfig');
      if (configStr) {
        try {
          const config = JSON.parse(configStr);
          setCustomSubjects(config);
        } catch (e) {
          console.error("Erro ao carregar configurações de disciplinas", e);
        }
      }
    };
    
    loadScheduleConfig();
    loadSubjectsConfig();
    
    // Escuta por atualizações nas configurações
    const handleScheduleUpdate = (event: Event) => {
      const customEvent = event as CustomEvent;
      if (customEvent.detail?.periodLabels) {
        const labels = customEvent.detail.periodLabels;
        setPeriods({
          period1: labels[0],
          period2: labels[1],
          period3: labels[2],
          period4: labels[3],
          period5: labels[4],
          interval: `Intervalo`,
        });
      }
    };
    
    const handleSubjectsUpdate = (event: Event) => {
      const customEvent = event as CustomEvent;
      if (customEvent.detail?.subjectsConfig) {
        setCustomSubjects(customEvent.detail.subjectsConfig);
      }
    };
    
    window.addEventListener('scheduleConfigUpdated', handleScheduleUpdate);
    window.addEventListener('subjectsConfigUpdated', handleSubjectsUpdate);
    return () => {
      window.removeEventListener('scheduleConfigUpdated', handleScheduleUpdate);
      window.removeEventListener('subjectsConfigUpdated', handleSubjectsUpdate);
    };
  }, []);

  // Group schedules by day of week
  const getSchedulesByDay = (day: string) => {
    const daySchedules = schedules?.filter(schedule => schedule.dayOfWeek === day) || [];
    // Sort by start time
    return daySchedules.sort((a, b) => {
      return a.startTime.localeCompare(b.startTime);
    });
  };

  // Função para obter o nome da disciplina conforme configuração
  const getSubjectName = (day: string, periodIndex: number) => {
    if (!customSubjects) return null;
    
    const periodKey = `subject${periodIndex}` as const;
    try {
      // Tenta obter o nome da disciplina das configurações personalizadas
      return customSubjects[day]?.[periodKey];
    } catch (e) {
      return null;
    }
  };
  
  // Days of the week
  const days = [
    { key: "monday", label: "Segunda" },
    { key: "tuesday", label: "Terça" },
    { key: "wednesday", label: "Quarta" },
    { key: "thursday", label: "Quinta" },
    { key: "friday", label: "Sexta" }
  ];
  
  // Function to get class item style
  const getClassItemStyle = (subject: string) => {
    if (subject === "Intervalo") {
      return "bg-secondary/40 border-secondary";
    }
    
    // Map subjects to specific colors
    const subjectColors: Record<string, string> = {
      "Matemática": "bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800",
      "Português": "bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800", 
      "História": "bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:border-amber-800",
      "Geografia": "bg-purple-50 border-purple-200 dark:bg-purple-900/20 dark:border-purple-800",
      "Ciências": "bg-cyan-50 border-cyan-200 dark:bg-cyan-900/20 dark:border-cyan-800",
      "Inglês": "bg-indigo-50 border-indigo-200 dark:bg-indigo-900/20 dark:border-indigo-800",
      "Ed. Física": "bg-red-50 border-red-200 dark:bg-red-900/20 dark:border-red-800",
      "Artes": "bg-pink-50 border-pink-200 dark:bg-pink-900/20 dark:border-pink-800"
    };
    
    return subjectColors[subject] || "bg-gray-50 border-gray-200 dark:bg-gray-800/30 dark:border-gray-700";
  };

  return (
    <div className="space-y-6">
      {/* Dialog para configurar horários */}
      <ScheduleConfigDialog 
        open={configDialogOpen}
        onOpenChange={setConfigDialogOpen}
      />
      
      {/* Dialog para configurar disciplinas */}
      <SubjectConfigDialog 
        open={subjectDialogOpen}
        onOpenChange={setSubjectDialogOpen}
      />
      
      <div className="bg-card shadow rounded-lg p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
          <div>
            <h2 className="text-xl gradient-heading mb-1">Horário de Aulas</h2>
            <div className="text-sm text-muted-foreground">
              Visualize o cronograma semanal de aulas
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2 mt-3 sm:mt-0">
            <Button 
              onClick={() => setSubjectDialogOpen(true)}
              variant="outline"
              className="hover:bg-background transition-colors"
            >
              <BookOpen className="mr-2 h-4 w-4" />
              Configurar Disciplinas
            </Button>
            
            <Button 
              onClick={() => setConfigDialogOpen(true)}
              variant="outline"
              className="hover:bg-background transition-colors"
            >
              <Settings className="mr-2 h-4 w-4" />
              Configurar Horários
            </Button>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="outline" className="flex items-center gap-1 bg-primary/5">
            <Clock className="h-3 w-3" />
            {periods.period1}
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 bg-primary/5">
            <Clock className="h-3 w-3" />
            {periods.period2}
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 bg-primary/5">
            <Clock className="h-3 w-3" />
            {periods.period3}
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 bg-secondary/10">
            <Clock className="h-3 w-3" />
            {periods.interval}
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 bg-primary/5">
            <Clock className="h-3 w-3" />
            {periods.period4}
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1 bg-primary/5">
            <Clock className="h-3 w-3" />
            {periods.period5}
          </Badge>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
            {days.map(day => (
              <Skeleton key={day.key} className="h-96 w-full" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
            {days.map(day => (
              <div key={day.key} className="border border-border rounded-lg overflow-hidden card-hover">
                <div className="bg-primary text-white px-4 py-2 font-medium">{day.label}</div>
                <div className="p-4 space-y-2">
                  <div className="border-l-4 rounded p-3 bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {getSubjectName(day.key, 1) || "Matemática"}
                      </div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        07:00 - 08:00
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-l-4 rounded p-3 bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {getSubjectName(day.key, 2) || "Português"}
                      </div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        08:00 - 09:00
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-l-4 rounded p-3 bg-secondary/40 border-secondary">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">Intervalo</div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        09:00 - 09:15
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Intervalo para lanche
                    </div>
                  </div>
                  
                  <div className="border-l-4 rounded p-3 bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:border-amber-800">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {getSubjectName(day.key, 3) || "História"}
                      </div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        09:15 - 10:15
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-l-4 rounded p-3 bg-purple-50 border-purple-200 dark:bg-purple-900/20 dark:border-purple-800">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {getSubjectName(day.key, 4) || "Geografia"}
                      </div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        10:15 - 11:15
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-l-4 rounded p-3 bg-cyan-50 border-cyan-200 dark:bg-cyan-900/20 dark:border-cyan-800">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {getSubjectName(day.key, 5) || "Ciências"}
                      </div>
                      <div className="text-xs bg-background px-2 py-1 rounded-full">
                        11:15 - 12:15
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
