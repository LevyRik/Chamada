import { useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { z } from "zod";

interface ScheduleConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Esquema para definição dos horários padrão
const timeConfigSchema = z.object({
  period1Start: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period1End: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period2Start: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period2End: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period3Start: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period3End: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  intervalStart: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  intervalEnd: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period4Start: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period4End: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period5Start: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
  period5End: z.string().regex(/^\d{2}:\d{2}$/, "Formato deve ser HH:MM"),
});

type TimeConfigFormValues = z.infer<typeof timeConfigSchema>;

export function ScheduleConfigDialog({ open, onOpenChange }: ScheduleConfigDialogProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Valores padrão para o formulário
  const defaultValues: TimeConfigFormValues = {
    period1Start: "07:00",
    period1End: "08:00",
    period2Start: "08:00",
    period2End: "09:00",
    period3Start: "09:15",
    period3End: "10:15",
    intervalStart: "09:00",
    intervalEnd: "09:15",
    period4Start: "10:15",
    period4End: "11:15",
    period5Start: "11:15",
    period5End: "12:15",
  };
  
  // Recuperar horários personalizados do localStorage, se existirem
  const getSavedTimes = (): TimeConfigFormValues => {
    const savedTimes = localStorage.getItem('scheduleConfig');
    if (savedTimes) {
      try {
        return JSON.parse(savedTimes);
      } catch (e) {
        console.error("Erro ao ler configurações salvas", e);
      }
    }
    return defaultValues;
  };
  
  const form = useForm<TimeConfigFormValues>({
    resolver: zodResolver(timeConfigSchema),
    defaultValues: getSavedTimes(),
  });
  
  // Função para salvar os horários
  const saveScheduleConfig = async (data: TimeConfigFormValues) => {
    setIsLoading(true);
    
    try {
      // Salvar no localStorage
      localStorage.setItem('scheduleConfig', JSON.stringify(data));
      
      // Atualizar o estado da aplicação
      const periodLabels = [
        `1ª Aula (${data.period1Start} - ${data.period1End})`,
        `2ª Aula (${data.period2Start} - ${data.period2End})`,
        `3ª Aula (${data.period3Start} - ${data.period3End})`,
        `4ª Aula (${data.period4Start} - ${data.period4End})`,
        `5ª Aula (${data.period5Start} - ${data.period5End})`,
      ];
      
      // Atualizar etiquetas de período em todo o sistema
      window.dispatchEvent(new CustomEvent('scheduleConfigUpdated', { 
        detail: { periodLabels } 
      }));
      
      // Notificar usuário
      toast({
        title: "Configurações salvas",
        description: "Os horários das aulas foram atualizados com sucesso.",
      });
      
      // Fechar diálogo
      onOpenChange(false);
    } catch (error) {
      console.error("Erro ao salvar configurações", error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar as configurações de horário.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Função para resetar para os valores padrão
  const resetToDefaults = () => {
    form.reset(defaultValues);
    toast({
      title: "Valores padrão",
      description: "Os horários foram restaurados para os valores padrão.",
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="gradient-heading">Configurar Horários de Aula</DialogTitle>
          <DialogDescription>
            Personalize os horários das aulas para se adaptar a diferentes turmas e salas de aula.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(saveScheduleConfig)} className="space-y-6">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Manhã - Primeiros Períodos</h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="period1Start"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>1ª Aula - Início</FormLabel>
                        <FormControl>
                          <Input placeholder="07:00" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="period1End"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>1ª Aula - Fim</FormLabel>
                        <FormControl>
                          <Input placeholder="07:50" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="period2Start"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2ª Aula - Início</FormLabel>
                      <FormControl>
                        <Input placeholder="07:50" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="period2End"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>2ª Aula - Fim</FormLabel>
                      <FormControl>
                        <Input placeholder="08:40" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="period3Start"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>3ª Aula - Início</FormLabel>
                      <FormControl>
                        <Input placeholder="08:40" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="period3End"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>3ª Aula - Fim</FormLabel>
                      <FormControl>
                        <Input placeholder="09:30" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-sm font-medium mb-2">Intervalo</h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="intervalStart"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Início</FormLabel>
                        <FormControl>
                          <Input placeholder="09:30" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="intervalEnd"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fim</FormLabel>
                        <FormControl>
                          <Input placeholder="09:50" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-sm font-medium mb-2">Manhã - Últimos Períodos</h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="period4Start"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>4ª Aula - Início</FormLabel>
                        <FormControl>
                          <Input placeholder="09:50" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="period4End"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>4ª Aula - Fim</FormLabel>
                        <FormControl>
                          <Input placeholder="10:40" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="period5Start"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>5ª Aula - Início</FormLabel>
                      <FormControl>
                        <Input placeholder="10:40" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="period5End"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>5ª Aula - Fim</FormLabel>
                      <FormControl>
                        <Input placeholder="11:30" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormDescription className="text-xs text-muted-foreground mt-2">
                Todos os horários devem estar no formato 24h (HH:MM).
              </FormDescription>
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={resetToDefaults}
              >
                Restaurar Padrão
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="ml-auto"
              >
                {isLoading ? "Salvando..." : "Salvar Configurações"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}