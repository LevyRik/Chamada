import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, startOfMonth, endOfMonth, differenceInBusinessDays } from 'date-fns';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Student, AttendanceRecord } from '@shared/schema';

type PeriodOption = 'semanal' | 'mensal';

export default function StudentAttendanceReport() {
  const [periodOption, setPeriodOption] = useState<PeriodOption>('semanal');
  
  // Query para obter todos os estudantes
  const { data: students, isLoading: isLoadingStudents } = useQuery<Student[]>({
    queryKey: ['/api/students'],
  });
  
  // Query para obter todos os registros de chamada
  const { data: attendanceRecords, isLoading: isLoadingAttendance } = useQuery<AttendanceRecord[]>({
    queryKey: ['/api/attendance'],
  });
  
  // Calcula a porcentagem de presença para cada aluno
  const calculateAttendanceReport = () => {
    if (!students || !attendanceRecords) return [];
    
    const today = new Date();
    let totalExpectedAttendance = 0;
    let startDate = new Date();
    
    // Define o período de análise com base na opção selecionada
    if (periodOption === 'semanal') {
      // 5 aulas por dia, 5 dias na semana
      totalExpectedAttendance = 25;
      const dayOfWeek = today.getDay();
      // Ajustar para iniciar da segunda-feira da semana atual
      const daysToSubtract = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
      startDate.setDate(today.getDate() - daysToSubtract);
      startDate.setHours(0, 0, 0, 0);
    } else {
      // 5 aulas por dia, aproximadamente 20 dias úteis no mês
      const monthStart = startOfMonth(today);
      const monthEnd = endOfMonth(today);
      const businessDays = differenceInBusinessDays(monthEnd, monthStart);
      totalExpectedAttendance = businessDays * 5;
      startDate = monthStart;
    }
    
    return students.map(student => {
      // Filtrar registros de presença do aluno no período
      const studentRecords = attendanceRecords.filter(record => {
        const recordDate = new Date(record.date);
        return record.studentId === student.id && recordDate >= startDate;
      });
      
      // Contar presenças
      const presentCount = studentRecords.filter(record => record.status === 'present').length;
      
      // Calcular porcentagem (corrigindo para não exceder 100%)
      const expectedAttendance = Math.min(totalExpectedAttendance, studentRecords.length || 1);
      const attendancePercent = Math.min(100, Math.round((presentCount / expectedAttendance) * 100));
      
      // Determinar status com base na porcentagem de presença
      let status = 'regular';
      let statusColor = 'text-amber-600';
      
      if (attendancePercent >= 75) {
        status = 'bom';
        statusColor = 'text-green-600';
      } else if (attendancePercent < 50) {
        status = 'crítico';
        statusColor = 'text-red-600';
      }
      
      return {
        student,
        presentCount,
        totalRecords: studentRecords.length,
        expectedAttendance,
        attendancePercent,
        status,
        statusColor
      };
    });
  };
  
  const attendanceReport = calculateAttendanceReport();
  
  const renderSkeletons = () => (
    <div className="space-y-4">
      {[1, 2, 3, 4, 5].map(i => (
        <div key={i} className="flex items-center space-x-4">
          <Skeleton className="h-12 w-12 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-[250px]" />
            <Skeleton className="h-4 w-[200px]" />
          </div>
        </div>
      ))}
    </div>
  );
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="gradient-heading">Relatório de Frequência</CardTitle>
        <CardDescription>
          Acompanhe a porcentagem de presença dos alunos
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="semanal" onValueChange={(value) => setPeriodOption(value as PeriodOption)}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="semanal">Semanal (25 aulas)</TabsTrigger>
            <TabsTrigger value="mensal">Mensal (100 aulas)</TabsTrigger>
          </TabsList>
          
          <TabsContent value="semanal" className="space-y-4">
            {isLoadingStudents || isLoadingAttendance ? (
              renderSkeletons()
            ) : attendanceReport.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Aluno</TableHead>
                    <TableHead>Frequência</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendanceReport.map(report => (
                    <TableRow key={report.student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            {report.student.avatarUrl ? (
                              <img 
                                src={report.student.avatarUrl} 
                                alt={report.student.name} 
                              />
                            ) : (
                              <AvatarFallback className="bg-primary/10 text-primary text-xs">
                                {report.student.name.charAt(0)}
                              </AvatarFallback>
                            )}
                          </Avatar>
                          <div className="font-medium">{report.student.name}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Progress 
                            value={report.attendancePercent} 
                            className={`h-2 ${
                              report.attendancePercent >= 75
                                ? "bg-green-100"
                                : report.attendancePercent >= 50
                                ? "bg-amber-100"
                                : "bg-red-100"
                            }`}
                          />
                          <div className="text-xs text-muted-foreground">
                            {report.presentCount} de {report.expectedAttendance} aulas
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`font-medium ${report.statusColor} capitalize`}>
                          {report.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {report.attendancePercent}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                Nenhum registro de presença encontrado.
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="mensal" className="space-y-4">
            {isLoadingStudents || isLoadingAttendance ? (
              renderSkeletons()
            ) : attendanceReport.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Aluno</TableHead>
                    <TableHead>Frequência</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendanceReport.map(report => (
                    <TableRow key={report.student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            {report.student.avatarUrl ? (
                              <img 
                                src={report.student.avatarUrl} 
                                alt={report.student.name} 
                              />
                            ) : (
                              <AvatarFallback className="bg-primary/10 text-primary text-xs">
                                {report.student.name.charAt(0)}
                              </AvatarFallback>
                            )}
                          </Avatar>
                          <div className="font-medium">{report.student.name}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Progress 
                            value={report.attendancePercent} 
                            className={`h-2 ${
                              report.attendancePercent >= 75
                                ? "bg-green-100"
                                : report.attendancePercent >= 50
                                ? "bg-amber-100"
                                : "bg-red-100"
                            }`}
                          />
                          <div className="text-xs text-muted-foreground">
                            {report.presentCount} de {report.expectedAttendance} aulas
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`font-medium ${report.statusColor} capitalize`}>
                          {report.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {report.attendancePercent}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                Nenhum registro de presença encontrado.
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <div className="mt-6 text-sm text-muted-foreground border-t pt-4">
          <p>
            <span className="font-medium text-green-600">Bom</span>: 75% ou mais de presença
          </p>
          <p>
            <span className="font-medium text-amber-600">Regular</span>: entre 50% e 74% de presença
          </p>
          <p>
            <span className="font-medium text-red-600">Crítico</span>: menos de 50% de presença
          </p>
        </div>
      </CardContent>
    </Card>
  );
}