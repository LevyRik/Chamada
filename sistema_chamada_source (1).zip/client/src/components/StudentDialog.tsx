import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStudentSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface StudentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  editingStudent?: {
    id: number;
    name: string;
    email: string;
    registrationNumber: string;
  };
}

export function StudentDialog({ 
  open, 
  onOpenChange, 
  onSuccess, 
  editingStudent 
}: StudentDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm({
    resolver: zodResolver(insertStudentSchema),
    defaultValues: editingStudent ? {
      name: editingStudent.name,
      email: editingStudent.email,
      registrationNumber: editingStudent.registrationNumber,
      avatarUrl: ''
    } : {
      name: '',
      email: '',
      registrationNumber: '',
      avatarUrl: ''
    }
  });

  async function onSubmit(data: any) {
    setIsSubmitting(true);
    
    try {
      if (editingStudent) {
        // Update existing student
        await apiRequest("PUT", `/api/students/${editingStudent.id}`, data);
        toast({
          title: "Sucesso",
          description: "Aluno atualizado com sucesso.",
        });
      } else {
        // Create new student
        await apiRequest("POST", "/api/students", data);
        toast({
          title: "Sucesso",
          description: "Aluno adicionado com sucesso.",
        });
      }
      
      onSuccess();
      onOpenChange(false);
      form.reset({
        name: '',
        email: '',
        registrationNumber: '',
        avatarUrl: ''
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao salvar o aluno. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {editingStudent ? "Editar Aluno" : "Adicionar Novo Aluno"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-2">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome Completo</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome do aluno" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="registrationNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>RA</FormLabel>
                  <FormControl>
                    <Input placeholder="Registro do aluno" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>E-mail</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="email@exemplo.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Salvando..." : editingStudent ? "Atualizar" : "Adicionar"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
