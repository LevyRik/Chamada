import React from 'react';

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  colorClass: string;
}

export function StatCard({ title, value, icon, colorClass }: StatCardProps) {
  return (
    <div className="bg-card shadow rounded-lg p-5 card-hover">
      <div className="flex items-center">
        <div className={`flex-shrink-0 ${colorClass} rounded-md p-3`}>
          {icon}
        </div>
        <div className="ml-5 w-0 flex-1">
          <dl>
            <dt className="text-sm font-medium text-muted-foreground truncate">{title}</dt>
            <dd>
              <div className="text-xl font-semibold gradient-heading">{value}</div>
            </dd>
          </dl>
        </div>
      </div>
    </div>
  );
}
