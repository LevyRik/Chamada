import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.attendance.app',
  appName: 'Sistema de Chamada',
  webDir: 'client/dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;